<?php
/**
 * TropaTT CRM connector for 1C-Bitrix: Управление сайтом (D7, Sale 16+).
 *
 * The module keeps a local queue (`b_tropatt_queue`) and a CAgent that pushes
 * orders to the TropaTT gateway, so a slow or unreachable CRM never blocks a
 * checkout, and a failed send is retried with backoff.
 */

use Bitrix\Main\Application;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;

Loc::loadMessages(__FILE__);

class tropatt_crm extends CModule
{
    public $MODULE_ID = 'tropatt.crm';
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $MODULE_GROUP_RIGHTS = 'Y';
    public $PARTNER_NAME = 'Anton Barinov';
    public $PARTNER_URI = 'https://tropatt.com';

    const QUEUE_TABLE = 'b_tropatt_queue';

    public function __construct()
    {
        $arModuleVersion = array();
        include __DIR__ . '/version.php';

        $this->MODULE_VERSION = $arModuleVersion['VERSION'];
        $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        $this->MODULE_NAME = Loc::getMessage('TROPATT_CRM_MODULE_NAME');
        $this->MODULE_DESCRIPTION = Loc::getMessage('TROPATT_CRM_MODULE_DESCRIPTION');
    }

    public function DoInstall()
    {
        global $APPLICATION;

        ModuleManager::registerModule($this->MODULE_ID);
        $this->InstallDB();
        $this->InstallEvents();
        $this->InstallAgents();
        $this->InstallFiles();

        $APPLICATION->IncludeAdminFile(
            Loc::getMessage('TROPATT_CRM_INSTALL_TITLE'),
            __DIR__ . '/step1.php'
        );
    }

    public function DoUninstall()
    {
        global $APPLICATION;

        $request = Application::getInstance()->getContext()->getRequest();
        $keepData = ($request->get('savedata') === 'Y');

        $this->UnInstallAgents();
        $this->UnInstallEvents();
        $this->UnInstallFiles();

        if (!$keepData) {
            $this->UnInstallDB();
        }

        ModuleManager::unRegisterModule($this->MODULE_ID);

        $APPLICATION->IncludeAdminFile(
            Loc::getMessage('TROPATT_CRM_UNINSTALL_TITLE'),
            __DIR__ . '/unstep1.php'
        );
    }

    public function InstallDB()
    {
        $connection = Application::getConnection();
        $sql = "CREATE TABLE IF NOT EXISTS " . self::QUEUE_TABLE . " (
            ID INT NOT NULL AUTO_INCREMENT,
            ORDER_ID INT NOT NULL,
            EVENT_TYPE VARCHAR(32) NOT NULL DEFAULT 'created',
            STATUS VARCHAR(16) NOT NULL DEFAULT 'PENDING',
            ATTEMPTS INT NOT NULL DEFAULT 0,
            LAST_ERROR TEXT NULL,
            CREATED_AT DATETIME NOT NULL,
            UPDATED_AT DATETIME NULL,
            PRIMARY KEY (ID),
            KEY ix_tropatt_queue_status (STATUS, ID),
            KEY ix_tropatt_queue_order (ORDER_ID, EVENT_TYPE, STATUS)
        )";
        $connection->queryExecute($sql);

        return true;
    }

    public function UnInstallDB()
    {
        Application::getConnection()->queryExecute('DROP TABLE IF EXISTS ' . self::QUEUE_TABLE);

        return true;
    }

    public function InstallEvents()
    {
        // D7 order events: a saved order and a changed status are both queued.
        RegisterModuleDependences('sale', 'OnSaleOrderSaved', $this->MODULE_ID, '\Tropatt\Crm\OrderHandler', 'onSaleOrderSaved', 100);
        RegisterModuleDependences('sale', 'OnSaleStatusOrderChange', $this->MODULE_ID, '\Tropatt\Crm\OrderHandler', 'onSaleStatusOrderChange', 100);

        return true;
    }

    public function UnInstallEvents()
    {
        UnRegisterModuleDependences('sale', 'OnSaleOrderSaved', $this->MODULE_ID, '\Tropatt\Crm\OrderHandler', 'onSaleOrderSaved');
        UnRegisterModuleDependences('sale', 'OnSaleStatusOrderChange', $this->MODULE_ID, '\Tropatt\Crm\OrderHandler', 'onSaleStatusOrderChange');

        return true;
    }

    /**
     * Route `/tropatt/v1/webhook` to the module entry point.
     *
     * @return bool
     */
    public function InstallFiles()
    {
        if (class_exists('\Bitrix\Main\UrlRewriter')) {
            $this->UnInstallFiles();
            \Bitrix\Main\UrlRewriter::add(array(
                'CONDITION' => '#^/tropatt/v1/webhook#',
                'RULE' => '',
                'ID' => 'tropatt.crm.webhook',
                'PATH' => '/bitrix/modules/tropatt.crm/webhook.php',
                'SORT' => 100,
            ));
        }

        return true;
    }

    /**
     * @return bool
     */
    public function UnInstallFiles()
    {
        if (class_exists('\Bitrix\Main\UrlRewriter')) {
            \Bitrix\Main\UrlRewriter::delete(array('ID' => 'tropatt.crm.webhook'));
        }

        return true;
    }

    public function InstallAgents()
    {
        CAgent::RemoveAgent('\Tropatt\Crm\Agent\QueueAgent::processQueue();', $this->MODULE_ID);
        CAgent::AddAgent(
            '\Tropatt\Crm\Agent\QueueAgent::processQueue();',
            $this->MODULE_ID,
            'N',
            60,
            '',
            'Y',
            ConvertTimeStamp(time() + CTimeZone::GetOffset() + 60, 'FULL')
        );

        return true;
    }

    public function UnInstallAgents()
    {
        CAgent::RemoveAgent('\Tropatt\Crm\Agent\QueueAgent::processQueue();', $this->MODULE_ID);

        return true;
    }
}
