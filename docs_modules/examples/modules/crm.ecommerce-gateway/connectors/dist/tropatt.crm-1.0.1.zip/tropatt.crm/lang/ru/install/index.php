<?php

$MESS['TROPATT_CRM_MODULE_NAME'] = 'TropaTT CRM — шлюз интернет-магазина';
$MESS['TROPATT_CRM_MODULE_DESCRIPTION'] = 'Двусторонняя синхронизация заказов, покупателей и статусов между 1C-Битрикс (Sale, D7) и TropaTT CRM.';
$MESS['TROPATT_CRM_INSTALL_TITLE'] = 'Установка модуля TropaTT CRM';
$MESS['TROPATT_CRM_UNINSTALL_TITLE'] = 'Удаление модуля TropaTT CRM';
