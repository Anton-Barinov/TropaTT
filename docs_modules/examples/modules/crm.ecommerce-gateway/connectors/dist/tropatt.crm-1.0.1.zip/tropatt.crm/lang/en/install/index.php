<?php

$MESS['TROPATT_CRM_MODULE_NAME'] = 'TropaTT CRM — store gateway';
$MESS['TROPATT_CRM_MODULE_DESCRIPTION'] = 'Two-way synchronisation of orders, customers and statuses between 1C-Bitrix (Sale, D7) and TropaTT CRM.';
$MESS['TROPATT_CRM_INSTALL_TITLE'] = 'Install the TropaTT CRM module';
$MESS['TROPATT_CRM_UNINSTALL_TITLE'] = 'Uninstall the TropaTT CRM module';
