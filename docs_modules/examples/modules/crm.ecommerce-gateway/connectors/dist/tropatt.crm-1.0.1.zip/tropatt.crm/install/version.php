<?php

$arModuleVersion = array(
    'VERSION' => '1.0.1',
    'VERSION_DATE' => '2026-09-15 16:00:00',
);
