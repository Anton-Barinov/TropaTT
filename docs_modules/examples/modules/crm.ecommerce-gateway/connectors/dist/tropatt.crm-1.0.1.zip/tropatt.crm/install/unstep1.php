<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}
?>
<p>Модуль удалён. Очередь отправки (<code>b_tropatt_queue</code>) удалена, агент и обработчики событий сняты.</p>
